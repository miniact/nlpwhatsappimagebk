from django.apps import AppConfig


class ChatnlpConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chatnlp'
